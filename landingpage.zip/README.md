﻿# Landing page
Static HTML + CSS setup.

## Structure
- index.html
- css/styles.css
- js/main.js
- assets/logos, assets/qr, assets/images

## Run
Open index.html in a browser (or use VS Code Live Server).
